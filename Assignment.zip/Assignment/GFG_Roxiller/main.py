from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
import requests

app = Flask(__name__)

# Configuration for SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_transactions.db'
db = SQLAlchemy(app)

# Define model for product transactions
class ProductTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    transaction_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)

    def __repr__(self):
        return f"<ProductTransaction {self.id}>"

# Endpoint to initialize the database with seed data
@app.route('/initialize-database', methods=['POST'])
def initialize_database():
    # Fetch JSON data from the third-party API
    api_url = 'https://s3.amazonaws.com/roxiler.com/product_transaction.json'
    response = requests.get(api_url)
    data = response.json()

    # Initialize the database with seed data
    for entry in data:
        product_transaction = ProductTransaction(
            product_id=entry['product_id'],
            transaction_id=entry['transaction_id'],
            quantity=entry['quantity']
        )
        db.session.add(product_transaction)

    # Commit the changes to the database
    db.session.commit()

    return jsonify({'message': 'Database initialized successfully'}), 200

if __name__ == '__main__':
    app.run(debug=True)
