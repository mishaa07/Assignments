from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_
import requests

app = Flask(__name__)

# Configuration for SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_transactions.db'
db = SQLAlchemy(app)

# Define model for product transactions
class ProductTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    transaction_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
    product_title = db.Column(db.String(100))
    description = db.Column(db.Text)
    price = db.Column(db.Float)

    def __repr__(self):
        return f"<ProductTransaction {self.id}>"

# Fetch data from third-party API and store it in the database
def fetch_and_store_data():
    api_url = 'https://s3.amazonaws.com/roxiler.com/product_transaction.json'
    response = requests.get(api_url)
    data = response.json()

    for entry in data:
        product_transaction = ProductTransaction(
            product_id=entry['product_id'],
            transaction_id=entry['transaction_id'],
            quantity=entry['quantity'],
            product_title=entry['product_title'],
            description=entry['description'],
            price=entry['price']
        )
        db.session.add(product_transaction)
    db.session.commit()

# Endpoint to list all transactions with search and pagination
@app.route('/transactions', methods=['GET'])
def list_transactions():
    # Pagination parameters
    page = request.args.get('page', default=1, type=int)
    per_page = request.args.get('per_page', default=10, type=int)

    # Search parameter
    search_text = request.args.get('search', '')

    # Query product transactions
    query = ProductTransaction.query

    # Apply search filter if search text is provided
    if search_text:
        search_filter = or_(ProductTransaction.product_title.ilike(f"%{search_text}%"),
                            ProductTransaction.description.ilike(f"%{search_text}%"),
                            ProductTransaction.price.ilike(f"%{search_text}%"))
        query = query.filter(search_filter)

    # Apply pagination
    transactions = query.paginate(page=page, per_page=per_page)

    # Format response
    transaction_data = [{
        'product_id': transaction.product_id,
        'transaction_id': transaction.transaction_id,
        'quantity': transaction.quantity,
        'product_title': transaction.product_title,
        'description': transaction.description,
        'price': transaction.price
    } for transaction in transactions.items]

    return jsonify({
        'transactions': transaction_data,
        'page': transactions.page,
        'per_page': transactions.per_page,
        'total_pages': transactions.pages,
        'total_records': transactions.total
    }), 200

# Initialize the database with seed data from the third-party API
fetch_and_store_data()

if __name__ == '__main__':
    app.run(debug=True)
