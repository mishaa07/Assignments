from flask import Flask, jsonify, request
import requests

app = Flask(__name__)

# Endpoint to fetch data from all three APIs, combine responses, and send final response
@app.route('/combined-data', methods=['GET'])
def get_combined_data():
    try:
        # Fetch data from the first API
        first_api_url = 'http://first-api-url.com'
        response1 = requests.get(first_api_url)
        response1.raise_for_status()
        data1 = response1.json()

        # Fetch data from the second API
        second_api_url = 'http://second-api-url.com'
        response2 = requests.get(second_api_url)
        response2.raise_for_status()
        data2 = response2.json()

        # Fetch data from the third API
        third_api_url = 'http://third-api-url.com'
        response3 = requests.get(third_api_url)
        response3.raise_for_status()
        data3 = response3.json()

        # Combine responses
        combined_data = {
            'data_from_first_api': data1,
            'data_from_second_api': data2,
            'data_from_third_api': data3
        }

        return jsonify(combined_data), 200

    except requests.exceptions.RequestException as e:
        error_message = f"Error fetching data from API: {str(e)}"
        return jsonify({'error': error_message}), 500

if __name__ == '__main__':
    app.run(debug=True)
