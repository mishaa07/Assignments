from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from datetime import datetime

app = Flask(__name__)

# Configuration for SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_transactions.db'
db = SQLAlchemy(app)

# Define model for product transactions
class ProductTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    transaction_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
    category = db.Column(db.String(50))
    date_of_sale = db.Column(db.DateTime)

    def __repr__(self):
        return f"<ProductTransaction {self.id}>"

# Endpoint to get pie chart data for unique categories in a selected month
@app.route('/pie-chart', methods=['GET'])
def get_pie_chart():
    # Get month from request parameters
    month_name = request.args.get('month')
    if not month_name:
        return jsonify({'error': 'Month parameter is required.'}), 200

    try:
        # Convert month name to month number
        month_number = datetime.strptime(month_name, '%B').month

        # Query product transactions for the selected month
        transactions = ProductTransaction.query.filter(db.func.strftime('%m', ProductTransaction.date_of_sale) == str(month_number)).all()

        # Count the number of items in each category
        category_counts = {}
        for transaction in transactions:
            if transaction.category not in category_counts:
                category_counts[transaction.category] = transaction.quantity
            else:
                category_counts[transaction.category] += transaction.quantity

        return jsonify(category_counts), 200

    except ValueError:
        return jsonify({'error': 'Invalid month format. Please provide full month name (e.g., January, February, etc.).'}), 200

if __name__ == '__main__':
    app.run(debug=True)
