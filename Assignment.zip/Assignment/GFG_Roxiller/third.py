from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from datetime import datetime

app = Flask(__name__)

# Configuration for SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_transactions.db'
db = SQLAlchemy(app)

# Define model for product transactions
class ProductTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    transaction_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
    price = db.Column(db.Float)
    date_of_sale = db.Column(db.DateTime)

    def __repr__(self):
        return f"<ProductTransaction {self.id}>"

# Endpoint to get bar chart data for price ranges in a selected month
@app.route('/bar-chart', methods=['GET'])
def get_bar_chart():
    # Get month from request parameters
    month_name = request.args.get('month')
    if not month_name:
        return jsonify({'error': 'Month parameter is required.'}), 400

    try:
        # Convert month name to month number
        month_number = datetime.strptime(month_name, '%B').month

        # Define price ranges
        price_ranges = [
            {'range': '0 - 100', 'min': 0, 'max': 100},
            {'range': '101 - 200', 'min': 101, 'max': 200},
            {'range': '201 - 300', 'min': 201, 'max': 300},
            {'range': '301 - 400', 'min': 301, 'max': 400},
            {'range': '401 - 500', 'min': 401, 'max': 500},
            {'range': '501 - 600', 'min': 501, 'max': 600},
            {'range': '601 - 700', 'min': 601, 'max': 700},
            {'range': '701 - 800', 'min': 701, 'max': 800},
            {'range': '801 - 900', 'min': 801, 'max': 900},
            {'range': '901 - above', 'min': 901, 'max': float('inf')}
        ]

        # Initialize dictionary to store count of items in each price range
        price_range_counts = {range['range']: 0 for range in price_ranges}

        # Query product transactions for the selected month
        transactions = ProductTransaction.query.filter(db.func.strftime('%m', ProductTransaction.date_of_sale) == str(month_number)).all()

        # Count the number of items in each price range
        for transaction in transactions:
            for range in price_ranges:
                if range['min'] <= transaction.price <= range['max']:
                    price_range_counts[range['range']] += transaction.quantity

        return jsonify(price_range_counts), 200

    except ValueError:
        return jsonify({'error': 'Invalid month format. Please provide full month name (e.g., January, February, etc.).'}), 200

if __name__ == '__main__':
    app.run(debug=True)
