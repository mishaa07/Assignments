from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from datetime import datetime

app = Flask(__name__)

# Configuration for SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_transactions.db'
db = SQLAlchemy(app)

# Define model for product transactions
class ProductTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    transaction_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
    date_of_sale = db.Column(db.DateTime)

    def __repr__(self):
        return f"<ProductTransaction {self.id}>"

# Endpoint to get statistics for a selected month
@app.route('/statistics', methods=['GET'])
def get_statistics():
    # Get month from request parameters
    month_name = request.args.get('month')
    if not month_name:
        return jsonify({'error': 'Month parameter is required.'}), 200

    try:
        # Convert month name to month number
        month_number = datetime.strptime(month_name, '%B').month

        # Calculate total sale amount of selected month
        total_sale_amount = db.session.query(func.sum(ProductTransaction.quantity * ProductTransaction.price)).\
            filter(db.func.strftime('%m', ProductTransaction.date_of_sale) == str(month_number)).scalar()

        # Calculate total number of sold items of selected month
        total_sold_items = db.session.query(func.sum(ProductTransaction.quantity)).\
            filter(db.func.strftime('%m', ProductTransaction.date_of_sale) == str(month_number)).scalar()

        # Calculate total number of not sold items of selected month
        total_not_sold_items = db.session.query(func.sum(ProductTransaction.quantity)).\
            filter(db.func.strftime('%m', ProductTransaction.date_of_sale) == str(month_number),
                   ProductTransaction.transaction_id.is_(None)).scalar()

        if total_sale_amount is None:
            total_sale_amount = 0

        if total_sold_items is None:
            total_sold_items = 0

        if total_not_sold_items is None:
            total_not_sold_items = 0

        return jsonify({
            'total_sale_amount': total_sale_amount,
            'total_sold_items': total_sold_items,
            'total_not_sold_items': total_not_sold_items
        }), 200

    except ValueError:
        return jsonify({'error': 'Invalid month format. Please provide full month name (e.g., January, February, etc.).'}), 200

if __name__ == '__main__':
    app.run(debug=True)
