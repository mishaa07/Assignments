// App.js
import React, { useState, useEffect } from 'react';
import MonthDropdown from './MonthDropdown';
import TransactionTable from './TransactionTable';

function App() {
  const [selectedMonth, setSelectedMonth] = useState('March');
  const [searchText, setSearchText] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalSaleAmount, setTotalSaleAmount] = useState(0);
  const [totalSoldItems, setTotalSoldItems] = useState(0);
  const [totalNotSoldItems, setTotalNotSoldItems] = useState(0);

  useEffect(() => {
    fetchTransactions(selectedMonth, searchText, currentPage);
    fetchStatistics(selectedMonth);
  }, [selectedMonth, searchText, currentPage]);

  // Fetch transactions from API based on selected month, search text, and page number
  async function fetchTransactions(month, search, page) {
    try {
      const response = await fetch(`/transactions?month=${month}&search=${search}&page=${page}`);
      const data = await response.json();
      setTransactions(data.transactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  }

  // Fetch statistics (total sale amount, total sold items, total not sold items) for the selected month
  async function fetchStatistics(month) {
    try {
      const response = await fetch(`/statistics?month=${month}`);
      const data = await response.json();
      setTotalSaleAmount(data.totalSaleAmount);
      setTotalSoldItems(data.totalSoldItems);
      setTotalNotSoldItems(data.totalNotSoldItems);
    } catch (error) {
      console.error('Error fetching statistics:', error);
    }
  }

  // Function to handle month selection change
  function handleMonthChange(month) {
    setSelectedMonth(month);
  }

  // Function to handle search text change
  function handleSearchTextChange(e) {
    setSearchText(e.target.value);
  }

  // Function to handle next page button click
  function handleNextPage() {
    setCurrentPage(prevPage => prevPage + 1);
  }

  // Function to handle previous page button click
  function handlePreviousPage() {
    setCurrentPage(prevPage => Math.max(prevPage - 1, 1));
  }

  return (
    <div>
      <h2>Transactions for {selectedMonth}</h2>
      <MonthDropdown selectedMonth={selectedMonth} onSelectMonth={handleMonthChange} />
      <div>
        <label>Total Sale Amount:</label> <span>{totalSaleAmount}</span>
      </div>
      <div>
        <label>Total Sold Items:</label> <span>{totalSoldItems}</span>
      </div>
      <div>
        <label>Total Not Sold Items:</label> <span>{totalNotSoldItems}</span>
      </div>
      <input type="text" value={searchText} onChange={handleSearchTextChange} placeholder="Search transaction" />
      <TransactionTable transactions={transactions} />
      <button onClick={handlePreviousPage} disabled={currentPage === 1}>Previous</button>
      <button onClick={handleNextPage}>Next</button>
    </div>
  );
}

export default App;
